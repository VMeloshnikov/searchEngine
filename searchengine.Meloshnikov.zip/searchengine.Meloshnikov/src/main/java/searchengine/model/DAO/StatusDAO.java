package searchengine.model.DAO;

public enum StatusDAO {
    INDEXING,
    INDEXED,
    FAILED
}
