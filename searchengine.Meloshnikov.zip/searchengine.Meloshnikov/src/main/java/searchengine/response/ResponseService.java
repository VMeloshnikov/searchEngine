package searchengine.response;

public interface ResponseService {
    boolean getResult();
}
