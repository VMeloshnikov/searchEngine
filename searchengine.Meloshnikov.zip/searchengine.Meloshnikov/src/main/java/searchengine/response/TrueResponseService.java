package searchengine.response;

public class TrueResponseService implements ResponseService{

    @Override
    public boolean getResult() {
        return true;
    }
}
