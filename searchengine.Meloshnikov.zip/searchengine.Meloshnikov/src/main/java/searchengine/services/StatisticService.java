package searchengine.services;

import searchengine.response.StatisticResponseService;

public interface StatisticService {
    StatisticResponseService getStatistic();

    }
